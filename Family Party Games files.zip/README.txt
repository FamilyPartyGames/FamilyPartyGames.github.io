How to properly set up Family Party Games Terminal:

1. Extract all or move ALL files to a separate folder
2. DON'T delete anything
3. Make sure all files are in the same folder:
  •app.exe
  •DescribeMasterDecks.json
  •GameSettings.json
4. Create a shortcut  wherever you want for app.exe