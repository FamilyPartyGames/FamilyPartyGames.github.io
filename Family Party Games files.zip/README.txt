How to properly set up Family Party Games Terminal:

1. Delete ALL previous versions (Warning: this will reset all settings and things like Describe Master decks. These can be preserved by copying their respective files.)
2. Extract all or move ALL files to a separate folder
3. DON'T delete anything
4. Make sure all files are in the same folder:
  •app.exe
  •Resources/
   •DescribeMasterDecks.json
   •GameSettings.json
5. Create a shortcut wherever you want for app.exe